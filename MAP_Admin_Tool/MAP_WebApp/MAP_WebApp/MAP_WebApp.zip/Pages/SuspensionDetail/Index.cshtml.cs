﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MAP_WebApp.Data;
using MAP_WebApp.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MAP_WebApp.Models.DB;
using MAP_WebApp.Utils;

namespace MAP_WebApp.Pages.SuspensionDetail
{
    [Authorize]
    public class IndexModel : BaseModel
    {
        public IndexModel(ToolDBContext context, IHttpContextAccessor accessor)
        {
            _context = context;
            _accessor = accessor;
        }

        public fn_GetNotificaitonInfo NotificationInfo { get; set; }
        public List<SelectListItem> ApprovalStatusList = new List<SelectListItem>();
        public List<SelectListItem> LineApprovalStatusList = new List<SelectListItem>();
        public class Suspension
        {
            public int Id { get; set; }
            public string Contact1 { get; set; }
            public string Contact2 { get; set; }
            public string Contact3 { get; set; }
            public string Contact4 { get; set; }
            public string Contact5 { get; set; }
            public string Contact6 { get; set; }
            public string Email1 { get; set; }
            public string Email2 { get; set; }
            public string Email3 { get; set; }
            public string Email4 { get; set; }
            public string Email5 { get; set; }
            public string Address1 { get; set; }
            public string Address2 { get; set; }
            public int ApprovalStatus_id { get; set; }
            public string Notes { get; set; }
            public int ForReview { get; set; }
            public int VisibleForHP { get; set; }
            public List<SuspensionDetails> Details { get; set; }
        }

        public class SuspensionDetails {
            public int Id { get; set; }
            public bool SampleProof { get; set; }
            public int ApprovalStatus_id { get; set; }
            public string Notes { get; set; }
            public int? Reason_id { get; set; }
            public int? HPReason_id { get; set; }
            public bool Changed { get; set; }
        }
        public class ReplacementDetail {
            public int Id { get; set; }
            public int Notification_id { get; set; }
            public bool Checked { get; set; }
            public int ApprovalStatus_id { get; set; }
            public int? Reason_id { get; set; }
        }

        public async Task<IActionResult> OnGet(string Id)
        {
            if (!initPage())
                return new ForbidResult();

            try
            {
                NotificationInfo = await _context.fn_GetNotificaitonInfo.FromSql("SELECT * FROM fn_GetNotificaitonInfo({0},{1})", Id, CurrentUser.Id).FirstOrDefaultAsync();

                foreach (var option in await _context.fn_GetSCListDropDownFilter.FromSql("SELECT * FROM fn_GetSCListDropDownFilter({0},{1})", "3", CurrentUser.Id).OrderBy(e => e.Id).ToListAsync())
                    ApprovalStatusList.Add(new SelectListItem() { Value = option.Id.ToString(), Text = option.Options, Selected = (NotificationInfo.Approval_Status_id == option.Id? true : false) });
                foreach (var option in await _context.fn_GetSCListDropDownFilter.FromSql("SELECT * FROM fn_GetSCListDropDownFilter({0},{1})", "5", CurrentUser.Id).OrderBy(e => e.Id).ToListAsync())
                    LineApprovalStatusList.Add(new SelectListItem() { Value = option.Id.ToString(), Text = option.Options, Selected = (NotificationInfo.Approval_Status_id == option.Id ? true : false) });


                if (NotificationInfo == null)
                    return new NotFoundResult();
            }
            catch (Exception ex) { 
                
            }


            return Page();
        }

        public async Task<IActionResult> OnPostLoadDetails(string id)
        {
            if (!initPage())
                return new ForbidResult();


            try
            {
                var draw = HttpContext.Request.Form["draw"].FirstOrDefault();

                var start = Request.Form["start"].FirstOrDefault();

                var length = Request.Form["length"].FirstOrDefault();


                var searchValue = Request.Form["search[value]"].FirstOrDefault();

                int pageSize = length != null ? Convert.ToInt32(length) : 0;

                int skip = start != null ? Convert.ToInt32(start) : 0;

                int recordsTotal = 0;

                var data = await _context.fn_GetNotificaitonDetails
                    .FromSql("SELECT * FROM fn_GetNotificaitonDetails({0},{1})", id, CurrentUser.Id)
                    .ToListAsync();

                recordsTotal = data.Count();

                data = data.Skip(skip).Take(pageSize).ToList();

                return new JsonResult(new { draw = draw, recordsFiltered = recordsTotal, recordsTotal = recordsTotal, data = data });

            }
            catch (Exception ex)
            {
                return new JsonResult(new { code = -1, msg = ex.Message.ToString() });
            }
        }
        public async Task<IActionResult> OnPostSaveNotification([FromBody]Suspension data)
        {
            if (!initPage())
                return new ForbidResult();
            try
            {
                var lcNotification = _context.D_Notification.Where(f => f.Id == data.Id).FirstOrDefault();
                bool lcASChanged = lcNotification.ApprovalStatus_id != data.ApprovalStatus_id;
                lcNotification.ApprovalStatus_id = data.ApprovalStatus_id;
                lcNotification.Notes = data.Notes == "" ? null : data.Notes.st();
                lcNotification.C_User_ID = CurrentUser.Id;
                lcNotification.C_DateTime = DateTime.Now;
                lcNotification.Changed = true;
                if (CurrentUser.UserGroup_Id != 2 && data.ForReview != -1)
                    lcNotification.ForReview = data.ForReview;
                if (new int[] { 1, 2 }.Contains(CurrentUser.UserGroup_Id) && data.VisibleForHP != -1)
                    lcNotification.VisibleForHP = data.VisibleForHP;
                if (data.Details.Where(e => e.Changed && e.ApprovalStatus_id == 4).Count() > 0 &&
                    CurrentUser.UserGroup_Id != 3)
                    lcNotification.ForReview = 0;

                var lcNotificationContact = _context.D_NotificationContact.Where(f => f.Id == lcNotification.Contacts_id).FirstOrDefault();
                lcNotificationContact.Contact1 = data.Contact1 == "" ? null: data.Contact1.st();
                lcNotificationContact.Contact2 = data.Contact2 == "" ? null: data.Contact2.st();
                lcNotificationContact.Contact3 = data.Contact3 == "" ? null: data.Contact3.st();
                lcNotificationContact.Contact4 = data.Contact4 == "" ? null: data.Contact4.st();
                lcNotificationContact.Contact5 = data.Contact5 == "" ? null: data.Contact5.st();
                lcNotificationContact.Contact6 = data.Contact6 == "" ? null: data.Contact6.st();
                lcNotificationContact.Email1 = data.Email1 == "" ? null: data.Email1.st();
                lcNotificationContact.Email2 = data.Email2 == "" ? null: data.Email2.st();
                lcNotificationContact.Email3 = data.Email3 == "" ? null: data.Email3.st();
                lcNotificationContact.Email4 = data.Email4 == "" ? null: data.Email4.st();
                lcNotificationContact.Email5 = data.Email5 == "" ? null: data.Email5.st();
                lcNotificationContact.Address1 = data.Address1 == "" ? null: data.Address1.st();
                lcNotificationContact.Address2 = data.Address2 == "" ? null: data.Address2.st();
                lcNotificationContact.C_User_id = CurrentUser.Id;
                lcNotificationContact.C_DateTime = DateTime.Now;
                lcNotificationContact.Changed = true;

                foreach (SuspensionDetails lcSP in data.Details)
                {
                    var lcNotificationDetail = _context.D_NotificationDetail.Where(f => f.Id == lcSP.Id).FirstOrDefault();
                    lcNotificationDetail.ApprovalStatus_id = lcSP.ApprovalStatus_id;
                    lcNotificationDetail.SampleProof = lcSP.SampleProof;
                    lcNotificationDetail.Notes = lcSP.Notes == "" ? null : lcSP.Notes.st();
                    lcNotificationDetail.Reason_id = lcSP.Reason_id;
                    lcNotificationDetail.HPReason_id = lcSP.HPReason_id;
                    lcNotificationDetail.C_User_ID = CurrentUser.Id;
                    lcNotificationDetail.C_DateTime = DateTime.Now;
                    lcNotificationDetail.Changed = true;
                }
                await _context.SaveChangesAsync();

                if (!lcASChanged)
                {
                    if (_context.D_NotificationDetail.Where(f => f.Master_id == data.Id && f.ApprovalStatus_id != 4).Count() < lcNotification.ThresholdValue
                    && _context.fn_GetNotificaitonDetailsReplacements.FromSql("SELECT * FROM fn_GetNotificaitonDetailsReplacements({0},{1})", data.Id, CurrentUser.Id).Count() == 0)
                    {
                        lcNotification.ApprovalStatus_id = 4;
                        await _context.SaveChangesAsync();
                    }
                }

                return new JsonResult(new
                {
                    code = 1,
                    msg = ""
                });

            }
            catch (Exception ex)
            {
                return new JsonResult(new { code = -1, msg = ex.Message.ToString() });
            }
        }

        public async Task<IActionResult> OnPostLoadReplacements(string id)
        {
            if (!initPage())
                return new ForbidResult();


            try
            {
                var draw = HttpContext.Request.Form["draw"].FirstOrDefault();

                var start = Request.Form["start"].FirstOrDefault();

                var length = Request.Form["length"].FirstOrDefault();


                var searchValue = Request.Form["search[value]"].FirstOrDefault();

                int pageSize = length != null ? Convert.ToInt32(length) : 0;

                int skip = start != null ? Convert.ToInt32(start) : 0;

                int recordsTotal = 0;

                var data = await _context.fn_GetNotificaitonDetailsReplacements
                    .FromSql("SELECT * FROM fn_GetNotificaitonDetailsReplacements({0},{1})", id, CurrentUser.Id)
                    .ToListAsync();

                recordsTotal = data.Count();

                if (length != "-1")
                    data = data.Skip(skip).Take(pageSize).ToList();

                return new JsonResult(new { draw = draw, recordsFiltered = recordsTotal, recordsTotal = recordsTotal, data = data });

            }
            catch (Exception ex)
            {
                return new JsonResult(new { code = -1, msg = ex.Message.ToString() });
            }
        }
        public async Task<IActionResult> OnGetReason(string Id, string ReasonType)
        {
            if (!initPage())
                return new JsonResult(new { code = -1, msg = "Forbidden" });

            try
            {
                var options = await _context.fn_GetReasons
                    .FromSql("SELECT * FROM fn_GetReasons({0},{1})", Id, ReasonType)
                    .OrderBy(e => e.Id)
                    .Select(e => new { e.Id, e.Options })
                    .ToListAsync();

                return new JsonResult(new { code = 1, msg = options });
            }
            catch (Exception ex)
            {
                //if (_hostingEnv.IsDevelopment())
                //    return new JsonResult(new { code = -1, msg = ex.Message.ToString() });
                //else
                    return new JsonResult(new { code = -1, msg = Const.ErrorMessage });
            }
        }

        public async Task<IActionResult> OnPostSaveReplacement([FromBody]List<ReplacementDetail> data)
        {
            if (!initPage())
                return new ForbidResult();
            try
            {

                foreach (ReplacementDetail lcSP in data)
                {
                    var lcReplacements = _context.D_NotificationDetailReplacements.Where(f => f.Id == lcSP.Id).FirstOrDefault();

                    lcReplacements.ReplacementApprovalStatus_Id = lcSP.ApprovalStatus_id;
                    lcReplacements.Reason_id = lcSP.Reason_id;
                    lcReplacements.C_User_ID = CurrentUser.Id;
                    lcReplacements.C_DateTime = DateTime.Now;
                    lcReplacements.Changed = true;

                    if (lcSP.Checked)
                    {
                        lcReplacements.UsedInNotification = true;
                        var result = await _context.usp_common.FromSql("EXEC usp_AddReplacement {0},{1},{2}",
                            lcSP.Id,
                            lcSP.Notification_id,
                            CurrentUser.Id
                        ).FirstOrDefaultAsync();
                        if (result.Code == -1)
                        {
                            return new JsonResult(new { code = result.Code, msg = result.Msg});
                        }
                    }
                }

                await _context.SaveChangesAsync();

                return new JsonResult(new { code = 1, msg = "" });

            }
            catch (Exception ex)
            {
                return new JsonResult(new { code = -1, msg = ex.Message.ToString() });
            }
        }
    }
}