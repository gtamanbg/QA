﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MAP_WebApp.Data;
using MAP_WebApp.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using MAP_WebApp.Models;
using Microsoft.Extensions.Options;


namespace MAP_WebApp.Pages
{
    [Authorize]
    public class IndexModel : BaseModel
    {
        private readonly CustomSettings _customSettings;
        public IndexModel(ToolDBContext context, IOptions<CustomSettings> CustomSettings, IHttpContextAccessor accessor)
        {
            _context = context;
            _accessor = accessor;
            _customSettings = CustomSettings.Value;
        }

        public List<SelectListItem> PolicyList = new List<SelectListItem>();
        public List<SelectListItem> SellerTypeList = new List<SelectListItem>();
        public List<SelectListItem> PenaltyTypeList = new List<SelectListItem>();
        public List<SelectListItem> SallerName = new List<SelectListItem>();
        public List<SelectListItem> ApprovalStatusList = new List<SelectListItem>();
        public List<SelectListItem> SellerSubTypeList = new List<SelectListItem>();
        public DateTime FirstDayOfPreviousWeek;
        public DateTime LastDayOfPreviousWeek;
        
        public class Notification
        {
            public int Id { get; set; }
            public int ApprovalStatus_id { get; set; }
            public string Notes { get; set; }
        }
        public async Task<IActionResult> OnGet()
        {
            if (!initPage())
                return new ForbidResult();
            
            foreach (var option in await _context.fn_GetSCListDropDownFilter.FromSql("SELECT * FROM fn_GetSCListDropDownFilter({0},{1})", "0", CurrentUser.Id).OrderBy(e => e.Id).ToListAsync())
                PolicyList.Add(new SelectListItem() { Value = option.Id.ToString(), Text = option.Options, Selected = true });
            foreach (var option in await _context.fn_GetSCListDropDownFilter.FromSql("SELECT * FROM fn_GetSCListDropDownFilter({0},{1})", "1", CurrentUser.Id).OrderBy(e => e.Id).ToListAsync())
                SellerTypeList.Add(new SelectListItem() { Value = option.Id.ToString(), Text = option.Options, Selected = true });
            foreach (var option in await _context.fn_GetSCListDropDownFilter.FromSql("SELECT * FROM fn_GetSCListDropDownFilter({0},{1})", "2", CurrentUser.Id).OrderBy(e => e.Id).ToListAsync())
                PenaltyTypeList.Add(new SelectListItem() { Value = option.Id.ToString(), Text = option.Options, Selected = true });
            foreach (var option in await _context.fn_GetSCListDropDownFilter.FromSql("SELECT * FROM fn_GetSCListDropDownFilter({0},{1})", "6", CurrentUser.Id).OrderBy(e => e.Id).ToListAsync())
                ApprovalStatusList.Add(new SelectListItem() { Value = option.Id.ToString(), Text = option.Options, Selected = true });
            foreach (var option in await _context.fn_GetSCListDropDownFilter.FromSql("SELECT * FROM fn_GetSCListDropDownFilter({0},{1})", "4", CurrentUser.Id).OrderBy(e => e.Id).ToListAsync())
                SallerName.Add(new SelectListItem() { Value = option.Options.ToString(), Text = option.Options, Selected = true });
             foreach (var option in await _context.fn_GetSCListDropDownFilter.FromSql("SELECT * FROM fn_GetSCListDropDownFilter({0},{1})", "7", CurrentUser.Id).OrderBy(e => e.Id).ToListAsync())
                SellerSubTypeList.Add(new SelectListItem() { Value = option.Options, Text = option.Options, Selected = true });
            
            var lcDateFilterDefValue = await _context.fn_GetFisrtAndLastDayOfWeek.FromSql("SELECT * FROM fn_GetFisrtAndLastDayOfWeek({0})", "").FirstOrDefaultAsync();
            FirstDayOfPreviousWeek = lcDateFilterDefValue.FistDayOfWeek;
            LastDayOfPreviousWeek = lcDateFilterDefValue.LastDayOfWeek;

            return Page();
        }

        public async Task<IActionResult> OnPostLoadTable(string fromDate, string toDate, string policy, string sellerType, string sellerSubType, string penaltyType, string sellerName, string hpApprovalStatus)
        {
            if (!initPage())
                return new ForbidResult();

            try
            {
                var draw = HttpContext.Request.Form["draw"].FirstOrDefault();

                var start = Request.Form["start"].FirstOrDefault();

                var length = Request.Form["length"].FirstOrDefault();


                var searchValue = Request.Form["search[value]"].FirstOrDefault();

                int pageSize = length != null ? Convert.ToInt32(length) : 0;

                int skip = start != null ? Convert.ToInt32(start) : 0;

                int recordsTotal = 0;

                var data = await _context.fn_GetNotificationList
                    .FromSql("SELECT * FROM fn_GetNotificationList({0},{1},{2},{3},{4},{5},{6},{7},{8})", CurrentUser.Id, fromDate, toDate, policy, sellerType, sellerSubType, penaltyType, sellerName, hpApprovalStatus)
                    .OrderBy(e => e.ApprovalStatusForOrder)
                    .ThenBy(e => e.Policy)
                    .ThenBy(e => e.SellerType_id)
                    .ThenBy(e => e.PenaltyType)
                    .ThenBy(e => e.Seller_Name)
                    .ThenBy(e => e.Product_Type)
                    .ToListAsync();

                recordsTotal = data.Count();
                if (length != "-1")
                    data = data.Skip(skip).Take(pageSize).ToList();

                return new JsonResult(new { draw = draw, recordsFiltered = recordsTotal, recordsTotal = recordsTotal, data = data });

            }
            catch (Exception ex)
            {
                throw;
            }

        }
        public async Task<IActionResult> OnPostUpdateApprovalStatus(IFormCollection form)
        {
            if (!initPage())
                return new ForbidResult();

            try
            {
                string lcNotification_id = form["id"].ToString();
                string lcFieldName = "ApprovalStatus_id";
                string lcFieldvalue = form["ApprovalStatus_id"].ToString();

                var result = await _context.usp_common.FromSql("EXEC usp_UpdateNotificationHeader {0},{1},{2},{3}", CurrentUser.Id, lcNotification_id, lcFieldName, lcFieldvalue).FirstOrDefaultAsync();

                return new JsonResult(new { code = result.Code, msg = result.Msg });
            }
            catch (Exception ex)
            {
                return new JsonResult(new { code = -1, msg = ex.Message.ToString() });
            }

        }

        public async Task<IActionResult> OnPostDownloadViolationDetail(IFormCollection form)
        {
            if (!initPage())
                return new JsonResult(new { code = -1, msg = "Forbidden" });

            try
            {
                string fromDate = form["fromDate"];
                string toDate = form["toDate"];
                string policy = form["policy"];
                string sellerType = form["sellerType"];
                string penaltyType = form["penaltyType"];
                string sellerName = form["sellerName"];
                string hpApprovalStatus = form["hpApprovalStatus"];

                string lcExportDate = DateTime.Now.ToString("[yyyy-MM-dd HH-mm-ss]");

                var destPath = Path.Combine(_customSettings.StorageFolder, CurrentUser.Id);
                if (!Directory.Exists(destPath))
                    Directory.CreateDirectory(destPath);

                destPath = Path.Combine(destPath, lcExportDate);
                System.IO.File.Copy(Path.Combine(_customSettings.TemplateFolder, "BB8B81C380124CA08FC539333A74F99E"), destPath);

                var parameters = string.Format("@inUser_Id={0}^@inFromDate={1}^@inToDate={2}^@inPolicy={3}^@inSellerType={4}^@inPenaltyType={5}^@inSellerName={6}^@inHPApprovalStatus={7}",
                    CurrentUser.Id, fromDate, toDate, policy, sellerType, penaltyType, sellerName.Replace("'","''"), hpApprovalStatus);

                var dstaSets = await _context.usp_GetDataSets.FromSql("EXEC usp_GetDataSets {0}, {1}", "BB8B81C380124CA08FC539333A74F99E", parameters).ToListAsync();

                ExcelUtils.FillExcel(destPath, dstaSets);

                return new JsonResult(new { code = 1, msg = lcExportDate });
            }
            catch (Exception ex)
            {
                return new JsonResult(new { code = -1, msg = ex.Message.ToString() });
            }
        }
        public async Task<IActionResult> OnPostUpdateNotes(IFormCollection form)
        {
            if (!initPage())
                return new ForbidResult();

            try
            {
                string lcNotification_id = form["id"].ToString();
                string lcFieldName = "Notes";
                string lcFieldvalue = form["Notes"].ToString();

                var result = await _context.usp_common.FromSql("EXEC usp_UpdateNotificationHeader {0},{1},{2},{3}", CurrentUser.Id, lcNotification_id, lcFieldName, lcFieldvalue).FirstOrDefaultAsync();

                return new JsonResult(new { code = result.Code, msg = result.Msg });
            }
            catch (Exception ex)
            {
                return new JsonResult(new { code = -1, msg = ex.Message.ToString() });
            }

        }

        public async Task<IActionResult> OnPostSaveNotification([FromBody]List<Notification> inData)
        {
            if (!initPage())
                return new ForbidResult();
            try
            {
                foreach(Notification data in inData)
                {
                    var lcNotification = _context.D_Notification.Where(f => f.Id == data.Id).FirstOrDefault();
                    bool lcASChanged = lcNotification.ApprovalStatus_id != data.ApprovalStatus_id;
                    lcNotification.ApprovalStatus_id = data.ApprovalStatus_id;
                    lcNotification.Notes = data.Notes == "" ? null : data.Notes.st();
                    lcNotification.C_User_ID = CurrentUser.Id;
                    lcNotification.C_DateTime = DateTime.Now;

                    if (!lcASChanged)
                    {
                        if (_context.D_NotificationDetail.Where(f => f.Master_id == data.Id && f.ApprovalStatus_id != 4).Count() < lcNotification.ThresholdValue &&
                            (
                                (lcNotification.Penalty == "DGF") ||
                                (lcNotification.Penalty != "DGF" && _context.fn_GetNotificaitonDetailsReplacements.FromSql("SELECT * FROM fn_GetNotificaitonDetailsReplacements({0},{1})", data.Id, CurrentUser.Id).Count() == 0)
                            )
                        )
                            lcNotification.ApprovalStatus_id = 4;
                    }
                }
                
                await _context.SaveChangesAsync();

                return new JsonResult(new
                {
                    code = 1,
                    msg = ""
                });

            }
            catch (Exception ex)
            {
                return new JsonResult(new { code = -1, msg = ex.Message.ToString() });
            }

        }
    }
}