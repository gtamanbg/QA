using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Okta.AspNetCore;
using MAP_WebApp.Utils;

namespace MAP_WebApp.Pages.User
{
    [Authorize]
    public class SignOutModel : BaseModel
    {
        public IActionResult OnPost()
        {
            initPage();

            return new SignOutResult(new[]{OktaDefaults.MvcAuthenticationScheme, CookieAuthenticationDefaults.AuthenticationScheme,}, new AuthenticationProperties { RedirectUri = "/" });
        }
    }
}