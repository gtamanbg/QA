﻿using Microsoft.EntityFrameworkCore;
using MAP_WebApp.Models.DB;
using System.Linq;

namespace MAP_WebApp.Data
{
    public class ToolDBContext : DbContext
    {
        public ToolDBContext(DbContextOptions<ToolDBContext> options)
        : base(options)
        {
            
        }

        
        public DbSet<N_Users> N_Users { get; set; }
        public DbSet<N_UserGroups> N_UserGroups { get; set; }
        public DbSet<D_NotificationDetail> D_NotificationDetail { get; set; }
        public DbSet<D_NotificationDetailReplacements> D_NotificationDetailReplacements { get; set; }
        public DbSet<D_Notification> D_Notification { get; set; }
        public DbSet<D_NotificationContact> D_NotificationContact { get; set; }

        public DbQuery<fn_AdminGetUserList> fn_AdminGetUserList { get; set; }
        public DbQuery<fn_AdminGetRequestLogs> fn_AdminGetRequestLogs { get; set; }
        public DbQuery<fn_GetNotificationList> fn_GetNotificationList { get; set; }
        public DbQuery<fn_GetSCListDropDownFilter> fn_GetSCListDropDownFilter { get; set; }
        public DbQuery<fn_GetNotificaitonInfo> fn_GetNotificaitonInfo { get; set; }
        public DbQuery<fn_GetNotificaitonDetails> fn_GetNotificaitonDetails { get; set; }
        public DbQuery<fn_GetNotificationDetailChange> fn_GetNotificationDetailChange { get; set; }
        public DbQuery<fn_GetFisrtAndLastDayOfWeek> fn_GetFisrtAndLastDayOfWeek { get; set; }
        public DbQuery<fn_GetReasons> fn_GetReasons { get; set; }
        public DbQuery<fn_GetNotificaitonDetailsReplacements> fn_GetNotificaitonDetailsReplacements { get; set; }

        public DbQuery<usp_common> usp_common { get; set; }
        public DbQuery<usp_GetDataSets> usp_GetDataSets { get; set; }

        public DbQuery<X_CurrentUser> X_CurrentUser { get; set; }
    }
}
