﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your Javascript code.

var ChangedInputArray = [];
var pblAccContactList = [2, 3, 4, 5, 6];
var pblIntContactList = [2, 3, 4, 5];
var pblInFieldChange = false;
function st(s) {
    if (s == null)
        return null;
    return s.toString().replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#x27;').replace(/\//g, '&#x2F;');
}
function strDecode(str) {
    return str == null ? null : he.decode(str);
};

function SuspensionDataSerialization() {
    var check = 0;
    var Details = []
    $('#tblViolationDetails > tbody  > tr').each(function (index, tr) {
        var rowId = tr.getAttribute('row-id');

        if (($('#AS_' + rowId).val() == 3 || $('#AS_' + rowId).val() == 4) && $('#N_' + rowId).val() == "") {
            SetInputColor($('#N_' + rowId), '#ff0000');
            $('#N_' + rowId).focus();
            check = -1;
            return;
        }
        if (($('#AS_' + rowId).val() == 3 || $('#AS_' + rowId).val() == 4) && $('#R_' + rowId).val() == "") {
            bootbox.alert({ title: '<div class="row"><div class="col-1"><img src="/img/error.png" width="20" style="position:absolute; padding-top:2px"/></div><div class="col">Error</div></div>', closeButton: false, centerVertical: true, message: '<h5>Аn error occurred while saving data: Missing reason!</h5>' });
            check = -1;
            $('#R_' + rowId).focus();
            return;
        }
        if (tr.getAttribute('data-changed') == 1)
            Details.push({
                Id: rowId,
                SampleProof: $('#SP_' + rowId).is(":checked"),
                ApprovalStatus_id: $('#AS_' + rowId).val(),
                Notes: $('#N_' + rowId).val(),
                Reason_id: $('#R_' + rowId).val(),
                HPReason_id: $('#HPR_' + rowId).val(),
                Changed: tr.getAttribute('data-changed') == 1
            });
    });
    if (check == -1)
        return check;
    var lcNotification = {
        Id: NotificationId,
        Contact1: $('#Contact1').val(),
        Contact2: $('#Contact2').val(),
        Contact3: $('#Contact3').val(),
        Contact4: $('#Contact4').val(),
        Contact5: $('#Contact5').val(),
        Contact6: $('#Contact6').val(),
        Email1: $('#Email1').val(),
        Email2: $('#Email2').val(),
        Email3: $('#Email3').val(),
        Email4: $('#Email4').val(),
        Email5: $('#Email5').val(),
        Address1: $('#Address1').val(),
        Address2: $('#Address2').val(),
        ApprovalStatus_id: $('#ApprovalStatus_id').val(),
        Notes: $('#Notes').val(),
        ForReview: $('#ForReview').length >= 1 ? ($('#ForReview').prop("checked") == true ? 1 : 0) : -1,
        VisibleForHP: $('#VisibleForHP').length >= 1 ? ($('#VisibleForHP').prop("checked") == true ? 1 : 0) : -1,
        Details: Details
    }
    return lcNotification;
}

function ViolationDataSerialization(inChangedRow = "") {
    var check = 0;
    if (inChangedRow == "") 
        if (($('#ApprovalStatus_id').val() == 3 || $('#ApprovalStatus_id').val() == 4) && $('#Notes').val() == "") {
            SetInputColor($('#Notes'), '#ff0000');
            $('#Notes').focus();
            return -1;
        }
    
    var Details = []
    $('#tblViolationDetails > tbody  > tr').each(function (index, tr) {
        var rowId = tr.getAttribute('row-id');

        if (($('#AS_' + rowId).val() == 3 || $('#AS_' + rowId).val() == 4) && $('#N_' + rowId).val() == "") {
            SetInputColor($('#N_' + rowId), '#ff0000');
            $('#N_' + rowId).focus();
            check = -1;
        }
        if (($('#AS_' + rowId).val() == 3 || $('#AS_' + rowId).val() == 4) && $('#R_' + rowId).val() == "") {
            bootbox.alert({ title: '<div class="row"><div class="col-1"><img src="/img/error.png" width="20" style="position:absolute; padding-top:2px"/></div><div class="col">Error</div></div>', closeButton: false, centerVertical: true, message: '<h5>Аn error occurred while saving data: Missing reason!</h5>' });
            check = -1;
            $('#R_' + rowId).focus();
            return;
        }
        Details.push({
            Id: rowId,
            ApprovalStatus_id: $('#AS_' + rowId).val(),
            Alternative_Percent_Amount: $('#APA_' + rowId).val(),
            Notes: $('#N_' + rowId).val(),
            Reason_id: $('#R_' + rowId).val(),
            HPReason_id: $('#HPR_' + rowId).val(),
            Changed: tr.getAttribute('data-changed') == 1
        });
    });
    if (check == -1)
        return check;

    var lcNotification = {
        Id: NotificationId,
        Contact1: $('#Contact1').val(),
        Contact2: $('#Contact2').val(),
        Contact3: $('#Contact3').val(),
        Contact4: $('#Contact4').val(),
        Contact5: $('#Contact5').val(),
        Contact6: $('#Contact6').val(),
        Email1: $('#Email1').val(),
        Email2: $('#Email2').val(),
        Email3: $('#Email3').val(),
        Email4: $('#Email4').val(),
        Email5: $('#Email5').val(),
        Address1: $('#Address1').val(),
        Address2: $('#Address2').val(),
        ApprovalStatus_id: $('#ApprovalStatus_id').val(),
        Notes: $('#Notes').val(),
        ForReview: $('#ForReview').length >= 1? ($('#ForReview').prop("checked") == true ? 1 : 0) : -1,
        VisibleForHP: $('#VisibleForHP').length >= 1 ? ($('#VisibleForHP').prop("checked") == true ? 1 : 0) : -1,
        Details: Details
    }
    return lcNotification;
}

function AddMailManu(inAccOrInt, inIndex = 0, inVale = '') {
    if (inAccOrInt == 1) {
        var lcLastContact;
        if (pblIntContactList.length > 0) {
            var lcId = '';
            if (inIndex != 0) {
                if (!pblIntContactList.includes(inIndex))
                    return
                else
                    lcId = inIndex;
            }
            else
                lcId = pblIntContactList[0];

            var lcNewContact = '<dl class="row row-10" id="Email' + lcId + 'Row">' +
                '<dt class="col-5"></dt><dd><div class="row"><div class="col" style="padding-right:5px">' +
                '<input id="Email' + lcId + '" readonly type="text" class="form-control form-control-sm" placeholder="Enter valid email" value="' + inVale + '" onchange="OnChange();"></div>' +
                '<div class="col-1" style="padding-left:0px;padding-top:3px">' +
                '<img src = "/img/edit.png" style = "width: 22px;cursor: pointer;" href="#" data-id="Email' + lcId + '" data-toggle="modal" data-target="#EditContactDlg" title="Edit" />' +
                '</div></div></dd></dl>';

            $('#intContacts').children().each(function () {
                if (this.id.startsWith('Email'))
                    lcLastContact = this.id;
            });

            $('#' + lcLastContact).after(lcNewContact);
            //$('#Email' + lcId).focus();

            pblIntContactList = pblIntContactList.filter(e => e !== lcId)
        }

        if (pblIntContactList.length == 0)
            $('#lbAddEMail').remove();
    }
    else {
        var lcLastContact;
        if (pblAccContactList.length > 0) {
            var lcId = '';
            if (inIndex != 0) {
                if (!pblAccContactList.includes(inIndex))
                    return
                else
                    lcId = inIndex;
            }
            else
                lcId = pblAccContactList[0];

            var lcNewContact = '<dl class="row row-10" id="Contact' + lcId + 'Row">' +
                '<dt class="col-5"></dt><dd><div class="row"><div class="col" style="padding-right:5px">' +
                '<input id="Contact' + lcId + '" readonly type="text" class="form-control form-control-sm" placeholder="Enter valid email" value="' + inVale + '" onchange="OnChange();"></div>' +
                '<div class="col-1" style="padding-left:0px;padding-top:3px">' +
                '<img src = "/img/edit.png" style = "width: 22px;cursor: pointer;" href="#" data-id="Contact' + lcId + '" data-toggle="modal" data-target="#EditContactDlg" title="Edit" />'+
                '</div></div></dd></dl>';
            
            $('#accContacts').children().each(function () {
                if (this.id.startsWith('Contact'))
                    lcLastContact = this.id;
            });

            $('#' + lcLastContact).after(lcNewContact);
            //$('#Contact' + lcId).focus();

            pblAccContactList = pblAccContactList.filter(e => e !== lcId)
        }
        if (pblAccContactList.length == 0)
            $('#lbAddContact').remove();
    }
}

function SetInputColor(inputId, Color) {
    $(inputId).attr("style", 'border-color:' + Color + '; background-color: #f0fbff');
};

function NumberWithCommas(inputNum, inRoundUp="") {
    if (inRoundUp.toString() == "")
        inRoundUp = 2
    try {
        if (isNaN(inputNum) || inputNum == null || inputNum == 0)
            return '-'
        else
            return inputNum.toFixed(inRoundUp).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
    catch (err) {
        return '-'
    }
}

function StrTrunc(str, max, add) {
    add = add || '...';
    return (typeof str === 'string' && str.length > max ? str.substring(0, max) + add : str);
};

function inputLineOnKeyPress(input) {
    var keycode = event.keyCode;
    var valid =
        (keycode > 47 && keycode < 58) || // number keys
        keycode == 32 || keycode == 13 || // spacebar & return key(s) (if you want to allow carriage returns)
        (keycode > 64 && keycode < 91) || // letter keys
        (keycode > 95 && keycode < 112) || // numpad keys
        (keycode > 185 && keycode < 193) || // ;=,-./` (in order)
        (keycode > 218 && keycode < 223);   // [\]' (in order)
    if (!valid)
        return;

    var val = Number(input.value);

    if (isNaN(val) || val < 0 || (input.id.includes('disc_inp_') && val > 100))
        SetInputColor('#' + input.id, '#ff0000');
    else
        SetInputColor('#' + input.id, '#0026ff');

    if (!ChangedInputArray.includes(input))
        ChangedInputArray.push(input);
};

function LandingPageDataSerialization() {
    var check = 0;
    var lcNotification = []
    $('#tbl_notifications > tbody  > tr[data-changed="1"]').each(function (index, tr) {
        var rowId = tr.getAttribute('id');

        if (($('#AS_' + rowId).val() == 3 || $('#AS_' + rowId).val() == 4) && $('#N_' + rowId).val() == "") {
            SetInputColor($('#N_' + rowId), '#ff0000');
            if (check != -1)
                $('#N_' + rowId).focus();
            check = -1;
            return;
        }
        lcNotification.push({
            Id: rowId,
            ApprovalStatus_id: $('#AS_' + rowId).val(),
            Notes: $('#N_' + rowId).val()
        });
    });
    if (check == -1)
        return check;
    else
        return lcNotification;
}

function OnChange() {
    pblInFieldChange = true;
    $('#btnAdd').attr('disabled', 'disabled');
}

function LineFieldChange(input) {
    OnChange();
    lcId = $(input).attr('row-id');
    $('#tr_' + lcId).attr('data-changed', 1);
}

$('#EditContactDlg').on('show.bs.modal', function (e) {
    $('.modalTextInput').val('');
    let id = $(e.relatedTarget).data('id');
    lcContact = $('#' + id).val();
    lcName = lcContact.lastIndexOf("(") == -1 ? "" : lcContact.substring(0, lcContact.lastIndexOf("("));
    lceMail = lcContact.lastIndexOf("(") == -1 ? lcContact : lcContact.substring(lcContact.lastIndexOf("(") + 1, lcContact.length - 1);
    $('#edContactName').val(lcName);
    $('#edContacteMail').val(lceMail);
    $('#btnOk').data('id', id);
})

$('#btnOk').on('click', function () {
    let id = $(this).data('id');
    if ($('#edContactName').val() != "" && $('#edContacteMail').val().toString() != "")
        $('#' + id).val($('#edContactName').val() + '(' + $('#edContacteMail').val() + ')');
    else
        $('#' + id).val($('#edContactName').val() + $('#edContacteMail').val());
    $('#EditContactDlg').modal('toggle');
    OnChange();
})

function CreateStatusButtons(ShowForReview, ForReview, ShowVisibleForHP, VisibleForHP) {
    if (ShowForReview == 1) {
        $('#complianceSummaryHolder').append('<dl class="row row-10">' +
            '<dt class="col-4">For review</dt>' +
            '<dd>' +
                '<div style="width:153px">' +
                    '<div class="text-sm-left"><div class="custom-control custom-checkbox custom-control-inline form-control-sm border-0" style="padding:0px;margine-top:0px;margine-bottom:0px">' +
                        '<input type="checkbox"' + (ForReview == 1? ' checked':'') + ' class="custom-control-input" id="ForReview" name="ForReview" onchange="OnChange();"/>' +
                        '<label class="custom-control-label-datatable" for="ForReview"></label>' +
                    '</div></div>'+
            '</div></dd></dl>');
    }
    if (ShowVisibleForHP == 1) {
        $('#complianceSummaryHolder').append('<dl class="row row-10">' +
            '<dt class="col-4">Visible for HP</dt>' +
            '<dd>' +
            '<div style="width:153px">' +
            '<div class="custom-control custom-checkbox custom-control-inline form-control-sm border-0" style="padding:0px;margine-top:0px;margine-bottom:0px">' +
            '<input type="checkbox"' + (VisibleForHP == 1 ? ' checked' : '') + ' class="custom-control-input" id="VisibleForHP" name="VisibleForHP" onchange="OnChange();"/>' +
            '<label class="custom-control-label-datatable" for="VisibleForHP"></label>' +
            '</div>' +
            '</div></dd></dl>');
    }
}

function RemoveContact(e) {
    $('#' + e.getAttribute('data-id')).val('');
};