﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace MAP_WebApp.Utils
{
    public class Utils
    {
    }
    public class Const
    {
        public const string ErrorMessage = "Some error occurred. Please contact administrator.";
        public const string Error404 = "Resource not found. Please contact your administrator for more information.";
        public const string Error403 = "Access Denied. You dont have permitions to open that page. Please contact your administrator for more information.";
        public const string ErrorXXX = "An error occurred while processing your request. Please contact your administrator for more information.";

    }
    public static class Extensions
    {
        public static string NullIfWhiteSpace(this string value)
        {
            if (String.IsNullOrWhiteSpace(value)) { return null; }
            return value;
        }
        public static bool IsNumeric(this string str, NumberStyles style = NumberStyles.Number,
        CultureInfo culture = null)
        {
            double num;
            if (culture == null) culture = CultureInfo.InvariantCulture;
            return Double.TryParse(str, style, culture, out num) && !String.IsNullOrWhiteSpace(str);
        }

        public static string st(this string s)
        {
            if (s == null)
                return null;
            return s.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("\"", "&quot;").Replace("'", "&#x27;").Replace("/", "&#x2F;");
        }
    }
}
