﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MAP_WebApp.Data;
using MAP_WebApp.Models.DB;
using System.Linq;

namespace MAP_WebApp.Utils
{
    public partial class BaseModel : PageModel
    {
        protected ToolDBContext _context;
        protected IHttpContextAccessor _accessor;
        protected X_CurrentUser CurrentUser;

        public bool initPage(int[] UserGroup_Id = null)
        {
            LogUserRequest();
            UserGroup_Id = UserGroup_Id ?? new int[0];

            if (CurrentUser == null || CurrentUser.Blocked)
                return false;

            if (UserGroup_Id.Length > 0 && !UserGroup_Id.Contains(CurrentUser.UserGroup_Id))
                return false;

            ViewData["UserGroup_Id"] = CurrentUser.UserGroup_Id;

            return true;
        }

        private void LogUserRequest()
        {
            if (_context != null)
                CurrentUser = _context.X_CurrentUser.FromSql("exec usp_LogUserRequest {0},{1},{2},{3},{4},{5}",
                    User.FindFirst("sub").Value,
                    _accessor.HttpContext?.Request?.Path.ToString(),
                    _accessor.HttpContext?.Request?.QueryString.ToString(),
                    _accessor.HttpContext.Request?.Headers["User-Agent"].ToString(),
                    _accessor.HttpContext?.Connection?.RemoteIpAddress?.ToString(),
                    _accessor.HttpContext?.Request.HttpContext.TraceIdentifier.ToString()

                ).FirstOrDefault();
            else
                CurrentUser = null;
        }
    }
}