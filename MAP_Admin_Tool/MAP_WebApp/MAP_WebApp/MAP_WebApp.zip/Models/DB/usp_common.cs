﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MAP_WebApp.Models.DB
{
    public class usp_common
    {
        public int Code { get; set; }
        public string Msg { get; set; }
    }
}
