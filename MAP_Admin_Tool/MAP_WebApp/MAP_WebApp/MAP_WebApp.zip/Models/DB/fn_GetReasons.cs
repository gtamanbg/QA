﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MAP_WebApp.Models.DB
{
    public class fn_GetReasons
    {
        public int Id { get; set; }
        public string Options { get; set; }
    }
}
