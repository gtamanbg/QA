﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MAP_WebApp.Models.DB
{
    public class N_UserGroups
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
