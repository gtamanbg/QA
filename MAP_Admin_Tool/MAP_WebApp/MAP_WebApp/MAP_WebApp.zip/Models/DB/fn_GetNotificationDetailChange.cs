﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MAP_WebApp.Models.DB
{
    public class fn_GetNotificationDetailChange
    {
        public decimal Alternative_Penalty { get; set; }
        public decimal Alternative_Percent_Amount { get; set; }
        public decimal AdjustedPenalty { get; set; }
        public int HeaderApprovalStatus_id { get; set; }
    }
}
