﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MAP_WebApp.Models.DB
{
    public class usp_GetDataSets
    {
        public byte DSIndex { get; set; }
        public string SheetName { get; set; }
        public string Data { get; set; }
    }
}
