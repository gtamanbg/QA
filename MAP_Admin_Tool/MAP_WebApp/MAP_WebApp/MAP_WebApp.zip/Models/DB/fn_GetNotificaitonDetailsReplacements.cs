﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MAP_WebApp.Models.DB
{
    public class fn_GetNotificaitonDetailsReplacements
    {
        public int Id { get; set; }
        public int Master_Id { get; set; }
        public DateTime? Collected_Date { get; set; }
        public string sCollected_Date { get; set; }
        public string Data_Source { get; set; }
        public string Product_Type { get; set; }
        public string Product_Line { get; set; }
        public string SKU { get; set; }
        public string Product_Description { get; set; }
        public string Market { get; set; }
        public string Price_Location { get; set; }
        public string Screenshot_URL { get; set; }
        public decimal? Seller_Advertised_Price { get; set; }
        public decimal? Lowest_Possible_Price { get; set; }
        public decimal? MAP { get; set; }
        public decimal? Eligible_IR_Amount { get; set; }
        public Int16? Violation_Code { get; set; }
        public decimal? Total_Penalty { get; set; }
        public decimal? Three_Percent_of_Total { get; set; }
        public decimal? Alternative_Percent_Amount { get; set; }
        public decimal? Alternative_Penalty { get; set; }
        public int? ApprovalStatus_id { get; set; }
        public int? Reason_id { get; set; }
    }
}
