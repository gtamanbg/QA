﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MAP_WebApp.Models.DB
{
    public class fn_GetFisrtAndLastDayOfWeek
    {
        public DateTime FistDayOfWeek { get; set; }
        public DateTime LastDayOfWeek { get; set; }
    }
}
